# Bishops Bakery House — Artisan Baked Goods

Welcome to the official website for **Bishops Bakery House**, your destination for freshly handcrafted baked goods made with traditional methods and premium ingredients.

## 🎯 Overview

This is a modern, responsive website showcasing our bakery's premium products, menu, customer testimonials, and contact information. Built with clean HTML, CSS, and vanilla JavaScript for optimal performance.

## ✨ Features

- **Hero Slider** — Three dynamic hero slides with high-quality product images and smooth transitions
- **Featured Products** — Showcase of bestselling items with pricing and add-to-cart buttons
- **About Section** — Our story, values, and key achievements since 1999
- **Menu Collections** — Browse six categories: Sourdough Breads, Celebration Cakes, Viennoiserie, Seasonal Specials, Coffee & Beverages, and Custom Orders
- **Testimonials** — Customer reviews and ratings
- **Contact Section** — Easy-to-access business location and phone number (+256786750188)
- **Responsive Navigation** — Fixed navbar with smooth scrolling to all sections
- **Brand Logo** — Professional circular logo displayed in navbar and footer
- **Quick Links** — Fast access to key pages: Find Us, Contact, Catering, Recipes, and Careers

## 📁 File Structure

```
BISHOPS HOUSE BAKERY/
├── Bishops bakery house.html        # Main website file
├── README.md                         # This file
└── bishops bakery house images/
    ├── download.png                  # Business logo (displayed in navbar & footer, favicon)
    ├── WhatsApp Image 2026-04-25 at 11.36.53 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.36.54 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.36.55 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.36.56 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.37.05 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.37.06 PM.jpeg
    ├── WhatsApp Image 2026-04-25 at 11.37.06 PM (3).jpeg
    └── [Additional product & menu images]
```

## 🚀 How to Use

1. **Open the Website:**
   - Double-click `Bishops bakery house.html` or open it in your web browser
   - Or right-click → Open with → [Your Browser]

2. **Navigate Sections:**
   - Use the navigation bar at the top to jump to any section
   - Links include: Home, Featured, About, Menu, Testimonials
   - Smooth scrolling is enabled for all anchor links

3. **Slider Navigation:**
   - Use left/right arrow buttons to manually navigate hero slides
   - Click the numbered dots to jump to a specific slide
   - Auto-advances every 5 seconds

4. **Responsive Design:**
   - Website adapts beautifully to desktop, tablet, and mobile devices
   - Fixed navbar remains accessible on all screen sizes

## 🎨 Customization

### Update Contact Information
Edit the footer section to add your bakery's real details:
- **Phone:** Currently +256786750188
- **Address:** Update in footer contact section
- **Email:** Update in footer contact section
- **Social Media:** Add your Facebook, Instagram, Twitter links

### Change Product Information
- Update product names, descriptions, and prices in the Featured Products section
- Modify menu categories and item counts in the Menu Collections section

### Replace Images
- Swap images in `bishops bakery house images/` folder
- Keep the same filenames or update HTML references accordingly

### Adjust Colors
The website uses a warm, elegant color scheme defined in the CSS `:root` variables:
```css
--cream: #f7f1e8
--caramel: #c17f3d
--espresso: #2c1a0e
--gold: #d4a853
```

## 📱 Key Sections

| Section | Purpose |
|---------|---------|
| **Navigation** | Fixed top bar with logo and links to all sections |
| **Hero Slider** | Full-screen product showcase with call-to-action buttons |
| **Featured Products** | Grid of bestselling items (Sourdough, Chocolate Cake, Croissant, Fruit Tart) |
| **About** | Company history, values, and achievements |
| **Menu** | Six product category collections with item counts |
| **Testimonials** | 5-star customer reviews |
| **Call-to-Action** | Get in Touch section with prominent buttons |
| **Quick Links** | Fast navigation to Find Us, Contact, Catering, Recipes, Careers |
| **Footer** | Contact info, social links, quick references |

## 🎯 Slider Image Specifications

- **Slider Images:** 500px × 500px blocks displayed on the right side of each hero slide
- **Current Images:** Three high-quality bakery product photos
- **Location:** Positioned absolutely on the right; responsive positioning
- **Border Radius:** 20px rounded corners for polished look

## 📞 Contact Information

**Business:** Bishops Bakery House  
**Phone:** +256786750188  
**Location:** 123 Bakery Street, City, State 12345  
**Email:** info@bishopsbakery.com

---

## 🛠️ Technical Details

- **HTML5** — Semantic markup
- **CSS3** — Modern styling with CSS Grid, Flexbox, and animations
- **JavaScript (Vanilla)** — No dependencies; auto-sliding carousel with manual controls
- **Performance** — Lightweight, fast-loading, optimized images
- **Accessibility** — Alt text on all images, semantic HTML structure

## 📝 Notes

- All buttons in the hero slider now link to relevant sections:
  - Explore Menu → Menu section
  - Our Story → About section
  - Order Custom → Menu section
  - Gallery → Featured Products section
  - Visit Us / Find Location → Contact section

- The website is fully self-contained in a single HTML file for easy distribution and hosting

---

**© 2024 Bishops Bakery House. All rights reserved.**

*Last Updated: May 3, 2026*
